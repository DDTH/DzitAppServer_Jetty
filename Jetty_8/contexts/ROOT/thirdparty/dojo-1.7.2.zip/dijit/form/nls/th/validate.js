//>>built
define(
"dijit/form/nls/th/validate", //begin v1.x content
({
	invalidMessage: "ค่าที่ป้อนไม่ถูกต้อง",
	missingMessage: "จำเป็นต้องมีค่านี้",
	rangeMessage: "ค่านี้เกินช่วง"
})

//end v1.x content
);
