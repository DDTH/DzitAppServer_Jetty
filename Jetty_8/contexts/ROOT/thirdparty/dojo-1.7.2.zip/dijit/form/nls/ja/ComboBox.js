//>>built
define(
"dijit/form/nls/ja/ComboBox", //begin v1.x content
({
		previousMessage: "以前の選択項目",
		nextMessage: "追加の選択項目"
})
//end v1.x content
);
