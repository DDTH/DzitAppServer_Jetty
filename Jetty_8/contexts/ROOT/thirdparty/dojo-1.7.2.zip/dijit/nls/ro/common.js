//>>built
define(
"dijit/nls/ro/common", //begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Anulare",
	buttonSave: "Salvare",
	itemClose: "Închidere"
})

//end v1.x content
);
