//>>built
define(
"dijit/nls/it/loading", //begin v1.x content
({
	loadingState: "Caricamento in corso...",
	errorState: "Si è verificato un errore"
})
//end v1.x content
);
