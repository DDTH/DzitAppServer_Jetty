//>>built
define(
"dijit/nls/el/loading", //begin v1.x content
({
	loadingState: "Φόρτωση...",
	errorState: "Σας ζητούμε συγνώμη, παρουσιάστηκε σφάλμα"
})
//end v1.x content
);
