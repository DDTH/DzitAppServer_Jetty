define(
"dijit/form/nls/fr/validate", ({
	invalidMessage: "La valeur indiquée n'est pas correcte.",
	missingMessage: "Cette valeur est requise.",
	rangeMessage: "Cette valeur n'est pas comprise dans la plage autorisée."
})
);
